

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<script>window.location = "<?php echo e(url('/dashboard')); ?>";</script>
<?php else: ?>

<h1>Login</h1>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" class="btn btn-primary"><i class="fa fa-sign-in"></i> Login </button>
</form>
<p>No account? <a href="<?php echo e(route('signup')); ?>">Sign up</a></p>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student-app\resources\views/auth/login.blade.php ENDPATH**/ ?>