

<?php $__env->startSection('content'); ?>
 <?php if(auth()->guard()->check()): ?>
<script>window.location = "<?php echo e(url('/dashboard')); ?>";</script>
<?php else: ?>
<h1>Signup</h1>
<form method="POST" action="<?php echo e(route('signup')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
    <button type="submit" class="btn btn-primary"><i class="fa fa-user-plus"></i> Signup</button>
</form>
<p>Has existing account? <a href="<?php echo e(route('login')); ?>">Login</a></p>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student-app\resources\views/auth/signup.blade.php ENDPATH**/ ?>